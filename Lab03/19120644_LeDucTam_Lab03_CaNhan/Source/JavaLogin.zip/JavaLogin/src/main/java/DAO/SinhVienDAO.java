package DAO;

import Entities.NhanVien;
import Entities.SinhVien;
import Utils.HibernateUtils;
import org.hibernate.Session;
import org.hibernate.query.NativeQuery;

import java.util.List;

public class SinhVienDAO {
    public List<SinhVien> authenticateSinhVien(String username, String password){
        Session session= HibernateUtils.getFACTORY().openSession();
        NativeQuery query=session.createNativeQuery("EXEC SP_AUTHEN_SINHVIEN "+username+","+password);
//        Query query=session.createSQLQuery("EXEC SP_SEL_PUBLIC_NHANVIEN(:usrename,:password)").addEntity(NhanVien.class).setParameter("username",username).setParameter("password",password);
        List<SinhVien> sinhVienList= query.getResultList();
        return sinhVienList;
    }
}
