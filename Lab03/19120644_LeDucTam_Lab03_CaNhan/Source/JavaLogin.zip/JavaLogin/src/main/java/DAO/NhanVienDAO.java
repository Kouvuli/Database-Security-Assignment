package DAO;

import Entities.NhanVien;
import Entities.SinhVien;
import Utils.HibernateUtils;
import org.hibernate.Session;
import org.hibernate.query.NativeQuery;

import java.util.List;

public class NhanVienDAO {
    public List<NhanVien> authenticateNhanVien(String username, String password){
        Session session= HibernateUtils.getFACTORY().openSession();
        NativeQuery query=session.createNativeQuery("EXEC SP_AUTHEN_NHANVIEN "+username+","+password);
//        Query query=session.createSQLQuery("EXEC SP_SEL_PUBLIC_NHANVIEN(:usrename,:password)").addEntity(NhanVien.class).setParameter("username",username).setParameter("password",password);
        List<NhanVien> sinhVienList= query.getResultList();
        return sinhVienList;
    }
}
