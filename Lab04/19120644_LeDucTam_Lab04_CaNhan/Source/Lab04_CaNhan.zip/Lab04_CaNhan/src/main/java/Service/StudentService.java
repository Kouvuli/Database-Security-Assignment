package Service;

import Entities.Employee;
import Entities.Student;
import Utils.HibernateUtils;
import Utils.JDBCUtils;
import org.hibernate.Session;
import org.hibernate.query.NativeQuery;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class StudentService {
    public List<Student> authenticateSinhVien(String username, String password) throws SQLException {
        JDBCUtils utils=new JDBCUtils();
        Connection connection = utils.getConnection();
        Statement stmt = null;
        List<Student> studentList=new ArrayList<>();
        try{
            stmt = connection.createStatement();
            String query="EXEC SP_AUTHEN_SINHVIEN '"+username+"',"+password;
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                Student newStudent = new Student(rs.getString("MASV"), rs.getString("HOTEN"), new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S").parse(rs.getString("NGAYSINH")), rs.getString("DIACHI"),rs.getString("MALOP"));
                studentList.add(newStudent);
            }
        } catch (SQLException | ParseException exception) {
            exception.printStackTrace();
        } finally {
            stmt.close();
        }
        return studentList;
    }
}
