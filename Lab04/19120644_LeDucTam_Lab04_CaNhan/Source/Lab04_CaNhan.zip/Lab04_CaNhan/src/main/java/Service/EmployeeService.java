package Service;

import Entities.Employee;
import Utils.HashUtil;
import Utils.HibernateUtils;
import Utils.JDBCUtils;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EmployeeService {
    public void insertEmployee(Employee e) throws SQLException {
        JDBCUtils utils=new JDBCUtils();
        Connection connection = utils.getConnection();
        HashUtil hashUtil=new HashUtil();
        Statement stmt = null;

        try{
            stmt = connection.createStatement();
            CryptoService cryptoService=new CryptoService();
            String encryptSal=cryptoService.encryptAES(e.getSalary());
            String query = "EXEC SP_INS_ENCRYPT_NHANVIEN '" + e.getId() + "','" + e.getName() + "','" + e.getEmail() + "'," + encryptSal + ",'" + e.getUsername() + "'," + hashUtil.getSHA1(e.getPassword());
            stmt.execute(query);
        } catch (SQLException exception) {
            exception.printStackTrace();
        } finally {
            stmt.close();
        }

    }
    public List<Employee> authenticateNhanVien(String username, String password) throws SQLException {
        JDBCUtils utils=new JDBCUtils();
        Connection connection = utils.getConnection();
        Statement stmt = null;
        List<Employee> employeeList=new ArrayList<>();
        try{
            stmt = connection.createStatement();
            String query="EXEC SP_AUTHEN_NHANVIEN '"+username+"',"+password;
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                Employee newEmployee = new Employee(rs.getString("MANV"), rs.getString("HOTEN"), rs.getString("EMAIL"), rs.getString("LUONG"));
                employeeList.add(newEmployee);
            }
        }
        finally {
            stmt.close();
        }
        return employeeList;
    }

    public List<Employee> getEmployeeList() throws SQLException {
        JDBCUtils utils=new JDBCUtils();
        Connection connection = utils.getConnection();
        Statement stmt = null;
        List<Employee> employeeList=new ArrayList<>();
        try{
            stmt = connection.createStatement();
            String query="EXEC SP_SEL_ENCRYPT_NHANVIEN";
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                CryptoService cryptoService=new CryptoService();
                String decryptSal=cryptoService.decryptAES(rs.getString("LUONG"));

                Employee newEmployee = new Employee(rs.getString("MANV"), rs.getString("HOTEN"), rs.getString("EMAIL"), decryptSal);
                employeeList.add(newEmployee);
            }
        }
        finally {
            stmt.close();
        }
        return employeeList;
    }
}
