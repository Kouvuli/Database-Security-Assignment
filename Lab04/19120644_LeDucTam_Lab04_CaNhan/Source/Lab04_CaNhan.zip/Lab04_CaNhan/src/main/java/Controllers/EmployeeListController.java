package Controllers;

import Entities.Employee;
import Service.EmployeeService;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

public class EmployeeListController implements Initializable {
    @FXML
    private TableColumn<Employee, String> empEmailCol;

    @FXML
    private TableColumn<Employee, String> empIdCol;

    @FXML
    private TableColumn<Employee, String>empNameCol;

    @FXML
    private TableColumn<Employee, String> empSalCol;

    @FXML
    private TextField newEmail;

    @FXML
    private VBox newEmployeeVBox;

    @FXML
    private TextField newId;

    @FXML
    private TextField newName;

    @FXML
    private TextField newPassword;

    @FXML
    private TextField newSal;

    @FXML
    private TextField newUsername;

    @FXML
    private TableView<Employee> tableView;

    private boolean isNewEmployeeVisible=false;
    @FXML
    void logOutHandler(ActionEvent event) {
        Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
        window.close();
        Stage newWindow=new Stage();
        FXMLLoader loader=new FXMLLoader(getClass().getResource("/Layouts/login.fxml"));
        Parent root= null;
        try {
            root = loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Scene scene = new Scene(root);
        newWindow.setTitle("Login");
        newWindow.setScene(scene);
        newWindow.show();
    }

    @FXML
    void newHandler(ActionEvent event) {
        isNewEmployeeVisible=!isNewEmployeeVisible;
        newEmployeeVBox.setVisible(isNewEmployeeVisible);
    }

    @FXML
    void saveHandler(ActionEvent event) {
        if(!isValidInput()){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Lỗi");
            alert.setContentText("Dữ liệu nhập không hợp lệ!");
            alert.showAndWait();
        }else {
            EmployeeService employeeService=new EmployeeService();
            Employee employee = new Employee(newId.getText(), newName.getText(), newEmail.getText(), newSal.getText(), newUsername.getText(), newPassword.getText());
            try {
                employeeService.insertEmployee(employee);
                tableView.getItems().add(employee);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        newEmployeeVBox.setVisible(isNewEmployeeVisible);
        EmployeeService employeeService=new EmployeeService();
        List<Employee> employeeList = null;
        try {
            employeeList = employeeService.getEmployeeList();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if(!employeeList.isEmpty()){
            empIdCol.setCellValueFactory(new PropertyValueFactory<Employee,String>("id"));
            empNameCol.setCellValueFactory(new PropertyValueFactory<Employee,String>("name"));
            empSalCol.setCellValueFactory(new PropertyValueFactory<Employee,String>("salary"));
            empEmailCol.setCellValueFactory(new PropertyValueFactory<Employee,String>("email"));

            tableView.setItems(FXCollections.observableArrayList(employeeList));
        }
    }

    public boolean isValidInput(){
        if (newId.getText().isEmpty()){
            return false;
        }
        else if (newEmail.getText().isEmpty()){
            return false;
        }
        else if (newName.getText().isEmpty()){
            return false;
        }
        else if (newSal.getText().isEmpty()){
            return false;
        }
        else if (newPassword.getText().isEmpty()){
            return false;
        }
        else if (newUsername.getText().isEmpty()){
            return false;
        }
        return true;
    }
}
