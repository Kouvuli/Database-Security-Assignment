import Entities.Employee;
import Service.EmployeeService;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class Main extends Application {
    Stage window;
    Scene scene;
    @Override
    public void start(Stage stage) throws IOException {
        window =stage;
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("/Layouts/login.fxml"));
        scene = new Scene(loader.load());
        stage.setTitle("Đăng nhập");
        stage.setScene(scene);
        stage.show();
        EmployeeService service=new EmployeeService();
        try {
            List<Employee> list=service.getEmployeeList();

        } catch (SQLException e) {
            e.printStackTrace();
        }
//        EncryptUtil encryptUtil=new EncryptUtil();;
//
//        String algorithm = "AES/CBC/PKCS5Padding";
//        String cipherText = encryptUtil.encrypt("3000000","19120644");
//        String plainText = encryptUtil.decrypt(cipherText, "19120644");
//        System.out.println(cipherText);
    }
    public static void main(String[] args) {
        launch();
    }

}
