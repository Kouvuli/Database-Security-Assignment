package Service;

import Utils.JDBCUtils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CryptoService {
    public String encryptAES(String value) throws SQLException {
        JDBCUtils utils=new JDBCUtils();
        Connection connection = utils.getConnection();
        Statement stmt = null;
        String encryptResult=null;
        try{
            stmt = connection.createStatement();
            String query="EXEC ENCRYPT_AES_256 "+value;

            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                String prefix="0x";
                encryptResult=prefix.concat(rs.getString("ENCRYPTVALUE"));
            }

        } catch (SQLException exception) {
            exception.printStackTrace();
        }finally {
            stmt.close();
        }
        return encryptResult;
    }
    public String decryptAES(String value) throws SQLException {
        JDBCUtils utils=new JDBCUtils();
        Connection connection = utils.getConnection();
        Statement stmt = null;
        String decryptResult=null;
        try{
            stmt = connection.createStatement();
            String query="EXEC DECRYPT_AES_256 "+"0x".concat(value);

            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {

                decryptResult=rs.getString("DECRYPTVALUE");
            }

        } catch (SQLException exception) {
            exception.printStackTrace();
        }finally {
            stmt.close();
        }
        return decryptResult;
    }
}
