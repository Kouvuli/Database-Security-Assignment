package Controllers;


import Entities.Employee;
import Entities.Student;
import Service.EmployeeService;
import Service.StudentService;
import Utils.HashUtil;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class LoginController implements Initializable {
    @FXML
    private TextField password;

    @FXML
    private TextField username;

    @FXML
    void cancelHandler(ActionEvent event) {
        Stage window=(Stage) ((Node)event.getSource()).getScene().getWindow();
        window.close();
    }

    @FXML
    void loginHandler(ActionEvent event) throws IOException {
        if(!isValidInput()){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Lỗi");
            alert.setContentText("Dữ liệu nhập không hợp lệ!");
            alert.showAndWait();
        }else{
            EmployeeService employeeService=new EmployeeService();

            StudentService studentService=new StudentService();
            HashUtil hashUtil=new HashUtil();
            try{
                List<Student> studentList = studentService.authenticateSinhVien(username.getText(), hashUtil.getMd5(password.getText()));
                List<Employee> employeeList = employeeService.authenticateNhanVien(username.getText(), hashUtil.getSHA1(password.getText()));
                if(studentList.isEmpty()&& employeeList.isEmpty()){
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Lỗi");
                    alert.setContentText("Tên đăng nhập và mật khẩu không hợp lệ!");
                    alert.showAndWait();
                    return;
                }
                else{
                    Stage curWindow=(Stage)((Node)event.getSource()).getScene().getWindow();
                    curWindow.close();
                    Stage window=new Stage();
                    FXMLLoader loader=new FXMLLoader(getClass().getResource("/Layouts/employee-list.fxml"));
                    Parent root= null;
                    try {
                        root = loader.load();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Scene scene = new Scene(root);
                    window.setTitle("Danh sách nhân viên");
                    window.setScene(scene);
                    window.show();


                }
            }
            catch (Exception e){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Lỗi");
                alert.setContentText("Tên đăng nhập và mật khẩu không hợp lệ!");
                alert.showAndWait();
            }

        }

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        password.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(final ObservableValue<? extends String> ov, final String oldValue, final String newValue) {
                if (password.getText().length() > 35) {
                    String s = password.getText().substring(0, 35);
                    password.setText(s);
                }
            }
        });
        username.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(final ObservableValue<? extends String> ov, final String oldValue, final String newValue) {
                if (username.getText().length() > 35) {
                    String s = username.getText().substring(0, 35);
                    username.setText(s);
                }
            }
        });
    }
    public boolean isValidInput(){
        if(username.getText().isEmpty()){
            return false;
        }
        else if(password.getText().isEmpty()){
            return false;
        }
        return true;
    }
}
